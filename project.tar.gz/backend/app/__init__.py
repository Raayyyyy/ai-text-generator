from flask import Flask
from flask_cors import CORS
from config import Config

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    CORS(app)
    
    # 注册路由
    from app.routes import generate
    app.register_blueprint(generate.bp)
    
    return app